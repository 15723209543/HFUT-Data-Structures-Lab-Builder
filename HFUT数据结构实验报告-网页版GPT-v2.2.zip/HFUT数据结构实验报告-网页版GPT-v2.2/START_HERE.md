# START HERE

你正在执行一个完整的数据结构实验交付任务。用户会同时上传本任务包和实验要求 DOCX，可能还会上传教师源文件或测试数据。

## 必须读取

执行任何生成操作前，完整读取：

1. `任务要求.txt`
2. `hfut-ds-shiyanbaogao/SKILL.md`
3. `hfut-ds-shiyanbaogao/references/output-contract.md`
4. `hfut-ds-shiyanbaogao/references/report-schema.md`
5. `hfut-ds-shiyanbaogao/references/viva-guide.md`
6. 当识别到内置实验时，再读取 `hfut-ds-shiyanbaogao/references/starter-profiles.md`

把 `hfut-ds-shiyanbaogao` 的绝对解压路径记为 `SKILL_DIR`，从该目录调用脚本。不要假设 Skill 已安装到 Codex。

## 执行要求

1. 不修改上传的原 DOCX；先复制到输出工作目录。
2. 使用 `scripts/inspect_requirements.py` 识别标题、题数、测试数据、后三个语义章节和 starter profile。
3. 使用 `scripts/prepare_submission.py` 建立 `T1...TX`。
4. 教师同目录文件优先；没有教师附件且 profile 唯一匹配时使用内置 starter。
5. 每题只实现本题算法，使用类和对象封装；`main.cpp` 只准备测试数据、构造对象和调用成员函数。
6. 使用 `patch_gbk.py` 写学生声明和实现，使用 `write_gbk.py` 写 `main.cpp`，保证严格 GBK。
7. 实际运行要求中的全部测试数据；无法编译时不要声称已经运行。
8. 按 `report-schema.md` 写 `report-spec.json`，再用 `fill_report.py` 生成最终 DOCX。
9. 使用 `convert_report.py` 转 PDF 并渲染页面。逐页检查乱码、裁切、重叠和分页；转换工具缺失时如实报告。
10. 使用 `extract_viva_evidence.py` 从本次题目和实际代码提取证据，按 `viva-guide.md` 写 `viva-spec.json`。
11. 使用 `generate_viva_guide.py` 生成 `<实验名>-验收问答.pdf` 并逐页检查。每题至少 8 个简短专业问答，不展示源码，不写身份信息。
12. 运行 `validate_submission.py`，同时传入报告 spec 和 viva spec，修复全部错误。
13. 使用 `package_submission.py` 生成最终 ZIP，并回读验证。

## 交付规则

- 最终回复只需要给出完成版 ZIP，并简短列出题数、模拟问题总数、编译/运行状态、DOCX、实验报告 PDF、验收问答 PDF 状态和未验证项。
- 不要交付 `.hfut-ds-work`、渲染 PNG、临时 JSON、缓存、编译产物或任务包自身。
- 实验文件名、代码、报告、PDF 属性和 ZIP 内不得出现来源生成标记。
- 不把任务包之外的样例身份信息写入结果。
- 公开问题反馈只使用 `15723209543@163.com`。
